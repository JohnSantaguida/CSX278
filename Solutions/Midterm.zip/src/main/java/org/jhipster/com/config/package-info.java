/**
 * Spring Framework configuration files.
 */
package org.jhipster.com.config;

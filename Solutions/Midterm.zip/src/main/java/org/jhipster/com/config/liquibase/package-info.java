/**
 * Liquibase specific code.
 */
package org.jhipster.com.config.liquibase;

/**
 * Audit specific code.
 */
package org.jhipster.com.config.audit;

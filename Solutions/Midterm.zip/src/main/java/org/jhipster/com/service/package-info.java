/**
 * Service layer beans.
 */
package org.jhipster.com.service;

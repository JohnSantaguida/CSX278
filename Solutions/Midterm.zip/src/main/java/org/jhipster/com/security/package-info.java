/**
 * Spring Security configuration.
 */
package org.jhipster.com.security;
